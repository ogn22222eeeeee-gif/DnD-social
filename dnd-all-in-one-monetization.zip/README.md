# DND all-in-one website starter

Upload `index.html` to the root of a GitHub repository and connect the repository to Netlify.

This one-file responsive frontend includes a welcome screen inviting visitors to follow the DND Founder account, feed, post creation, direct public media URL previews, explore/search, video section, profile editor, local dashboard, follow buttons, notifications placeholder, live-stream setup placeholder, messaging preview, official bank/provider links, and safety/settings.

Important limitations:
- The welcome screen records the follow choice only in the visitor's browser. It cannot force or verify a global follow without real user accounts and a backend.
- Posts and follows are stored locally in each browser, not shared between visitors.
- Live streaming, real private messages, account authentication, media uploads, global notifications, moderation, and creator payments need secure backend and third-party service integration.
- DND does not create bank accounts or collect bank credentials.


## Monetization status
The site includes a creator monetization screen with demo balances and links to official Paystack and Flutterwave websites. Those links are not a live DND payout integration. Real earnings and withdrawals require provider onboarding, server-side integration, verified transactions, identity checks where required, payout verification, and secure account permissions. Never collect bank passwords, PINs, or OTPs in DND.
