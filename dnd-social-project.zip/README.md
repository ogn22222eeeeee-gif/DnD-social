# DND Social — project starter

A responsive front-end starter for DND Social with a premium dark UI, purple/neon accents, a logo, an illustrated hero graphic, mobile navigation, feed, create-post page, profile editor, dashboard layout, and marketplace preview.

## Project structure

```text
dnd-social-project/
├── index.html
├── README.md
└── assets/
    ├── css/
    │   └── style.css
    ├── js/
    │   └── app.js
    └── images/
        ├── dnd-logo.svg
        └── hero-orbit.svg
```

## Run it

This is a static site. Open `index.html` in a browser or deploy the folder to a static host.

### Netlify deployment

1. Upload the project files to a GitHub repository.
2. In Netlify, choose **Add new project / Import an existing project** and select the repository.
3. Build command: leave blank.
4. Publish directory: `.` (repository root).
5. Deploy.

If the repository already contains files you need, back them up before replacing or merging anything.

## What works in this starter

- Responsive desktop and mobile layout.
- Navigation between Home, Explore, Create, Videos, Marketplace, Dashboard, Profile, Messages, Notifications, and Settings.
- Local demo posts, likes, delete action, text search, topic filtering, and share action.
- Small local image/video attachments (browser storage limits apply).
- Local profile editor.
- Demo marketplace cards and dashboard preview.
- SVG logo and custom SVG hero artwork.

## What is not yet a real production feature

This is **not yet a multi-user social network**. Posts, likes, and profile data use the browser's `localStorage`; they are not shared with other users or stored in a server database. Marketplace cards are illustrative only.

Not connected yet:
- User registration, secure login, password recovery, and server-side permissions.
- Shared online posts, follows, comments, notifications, and direct messages.
- Cloud media upload, video transcoding, video recommendations, and live streaming.
- Seller accounts, orders, checkout, refunds, or payment processing.
- Creator monetization, earnings, payouts, and fraud prevention.
- Moderation tools, reporting, blocking, privacy controls, and production security monitoring.

## Next development stage

Connect Supabase (or another backend) for authentication and database storage. Before public launch, add and test access-control policies, validation, rate limits, reporting/moderation, privacy policy, terms, and secure payment/video integrations where needed.

Do not place service-role keys or other server secrets in front-end JavaScript. A public client key can be used only with correctly configured backend security policies.
