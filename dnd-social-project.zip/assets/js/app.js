/* DND Social front-end preview.
   Posts, likes, and profile data stay in this browser's localStorage.
   This is NOT a multi-user backend. Never store sensitive data here. */
(() => {
  "use strict";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const starterPosts = [
    {id:"starter-1",name:"DND Team",topic:"Community",text:"Welcome to DND Social ✨ This is the start of a community for creators, curious minds, and people with something to share. What should we build next?",likes:12,liked:false,time:"Welcome post",starter:true},
    {id:"starter-2",name:"Creator Corner",topic:"Creators",text:"Your first post doesn't need to be perfect. Start creating, keep learning, and let your voice be heard. 🚀",likes:8,liked:false,time:"Community inspiration",starter:true}
  ];
  const demoProducts = [
    {name:"Wireless headphones",category:"Tech",price:"Demo listing",emoji:"🎧"},
    {name:"Streetwear sneakers",category:"Fashion",price:"Demo listing",emoji:"👟"},
    {name:"Smart watch",category:"Tech",price:"Demo listing",emoji:"⌚"},
    {name:"Creator backpack",category:"Accessories",price:"Demo listing",emoji:"🎒"},
    {name:"Gaming controller",category:"Gaming",price:"Demo listing",emoji:"🎮"},
    {name:"Studio microphone",category:"Creator gear",price:"Demo listing",emoji:"🎙️"}
  ];
  let posts = read("dnd_posts", []);
  let profile = read("dnd_profile", {name:"DND Creator",bio:"Making my mark, one post at a time."});
  let toastTimer;

  function read(key, fallback) {
    try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
    catch (_) { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (_) { showToast("Browser storage is full. Remove some local demo posts and try again."); return false; }
  }
  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[char]));
  }
  function allPosts() { return [...posts, ...starterPosts]; }
  function initials(name) { return esc((name || "D").trim().slice(0,1).toUpperCase() || "D"); }
  function showToast(message) {
    const toast = $("#toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
  }
  function goToPage(page) {
    const target = $("#page-" + page);
    if (!target) return;
    $$(".page").forEach(el => el.classList.toggle("active", el === target));
    $$("[data-page-link]").forEach(button => button.classList.toggle("active", button.dataset.pageLink === page));
    $("#main-content")?.focus({preventScroll:true});
    window.scrollTo({top:0,behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"});
    if (page === "home") renderFeed();
    if (page === "explore") renderExplore();
    if (page === "videos") renderVideos();
    if (page === "marketplace") renderProducts();
    if (page === "dashboard") renderDashboard();
    if (page === "profile") renderProfile();
  }
  function mediaMarkup(post) {
    if (!post.media) return "";
    if (post.mediaType === "video") return `<video class="post-media" controls playsinline preload="metadata" src="${post.media}"></video>`;
    return `<img class="post-media" src="${post.media}" alt="Post attachment">`;
  }
  function postCard(post) {
    const userPost = posts.some(item => item.id === post.id);
    return `<article class="post-card">
      <div class="post-head"><span class="avatar">${initials(post.name)}</span>
        <div class="post-meta"><b>${esc(post.name || "DND Creator")}</b><small>${esc(post.time || "Just now")} · DND Social preview</small></div>
        <span class="post-topic">${esc(post.topic || "General")}</span>
      </div>
      ${post.text ? `<div class="post-body">${esc(post.text)}</div>` : ""}
      ${mediaMarkup(post)}
      <div class="post-actions">
        <button class="action-button ${post.liked ? "liked" : ""}" data-like="${esc(post.id)}" aria-pressed="${!!post.liked}">♡ <span>${Number(post.likes)||0}</span> Likes</button>
        <button class="action-button" data-share="${esc(post.id)}">↗ Share</button>
        ${userPost ? `<button class="action-button post-delete" data-delete="${esc(post.id)}">Delete</button>` : ""}
      </div>
    </article>`;
  }
  function renderInto(target, items, emptyMessage) {
    const container = $(target);
    if (!container) return;
    container.innerHTML = items.length ? items.map(postCard).join("") : `<div class="panel placeholder-panel"><span class="placeholder-icon">⌕</span><h2>Nothing here yet</h2><p>${esc(emptyMessage)}</p></div>`;
  }
  function renderFeed() {
    let items = allPosts();
    const query = ($("#global-search")?.value || "").trim().toLowerCase();
    items = items.filter(post => `${post.name} ${post.text} ${post.topic}`.toLowerCase().includes(query));
    if ($("#feed-sort")?.value === "popular") items.sort((a,b) => (b.likes||0)-(a.likes||0));
    renderInto("#feed-list", items, "Create the first post in this local preview.");
  }
  function renderExplore() {
    const query = ($("#explore-search")?.value || $("#global-search")?.value || "").trim().toLowerCase();
    const items = allPosts().filter(post => `${post.name} ${post.text} ${post.topic}`.toLowerCase().includes(query));
    renderInto("#explore-list", items, "Try another search or create a post.");
  }
  function renderVideos() {
    const videos = allPosts().filter(post => post.mediaType === "video");
    renderInto("#video-list", videos, "No local video posts yet. Use Create to select a small video from your phone. It will only be saved in this browser, not uploaded for other users.");
  }
  function renderProducts() {
    const query = ($("#market-search")?.value || "").trim().toLowerCase();
    const items = demoProducts.filter(product => `${product.name} ${product.category}`.toLowerCase().includes(query));
    $("#product-grid").innerHTML = items.map(product => `<article class="product-card">
      <div class="product-art" aria-hidden="true">${product.emoji}</div><h3>${esc(product.name)}</h3>
      <p>${esc(product.category)} · ${esc(product.price)}</p>
      <button class="button button-ghost" type="button" data-product="${esc(product.name)}">View listing</button>
    </article>`).join("") || `<div class="panel">No demo listings match your search.</div>`;
  }
  function renderDashboard() {
    $("#stat-posts").textContent = String(posts.length);
    $("#stat-likes").textContent = String(posts.reduce((sum, post) => sum + (Number(post.likes)||0), 0));
  }
  function renderProfile() {
    $("#top-profile-name").textContent = profile.name || "DND Creator";
    $("#composer-name").textContent = profile.name || "DND Creator";
    $("#composer-avatar").textContent = initials(profile.name);
    $("#profile-avatar").textContent = initials(profile.name);
    $("#profile-display-name").textContent = profile.name || "DND Creator";
    $("#profile-bio-display").textContent = profile.bio || "Making my mark, one post at a time.";
    $("#display-name").value = profile.name || "";
    $("#profile-bio").value = profile.bio || "";
    renderInto("#profile-posts", posts.filter(post => post.name === (profile.name || "DND Creator")), "Your posts will appear here after you publish them.");
  }
  function toggleLike(id) {
    const userPost = posts.find(post => post.id === id);
    if (userPost) {
      userPost.liked = !userPost.liked;
      userPost.likes = Math.max(0, (userPost.likes || 0) + (userPost.liked ? 1 : -1));
      save("dnd_posts", posts);
    } else {
      const starter = starterPosts.find(post => post.id === id);
      if (starter) {
        starter.liked = !starter.liked;
        starter.likes = Math.max(0, starter.likes + (starter.liked ? 1 : -1));
      }
    }
    renderFeed(); renderExplore(); renderVideos(); renderDashboard();
  }
  async function sharePost(id) {
    const post = allPosts().find(item => item.id === id);
    if (!post) return;
    const text = `${post.name} on DND Social: ${post.text || "Check out this post!"}`;
    try {
      if (navigator.share) await navigator.share({title:"DND Social", text});
      else if (navigator.clipboard) { await navigator.clipboard.writeText(text); showToast("Post text copied."); }
      else showToast(text);
    } catch (_) { /* User cancelled sharing. */ }
  }
  async function createPost(event) {
    event.preventDefault();
    const text = $("#post-text").value.trim();
    const file = $("#post-file").files[0];
    if (!text && !file) { showToast("Write a post or choose a photo/video first."); return; }
    if (file && file.size > 2 * 1024 * 1024) {
      showToast("This local preview supports files up to 2 MB. Real uploads need online storage.");
      return;
    }
    let media = "", mediaType = "";
    if (file) {
      try {
        media = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        mediaType = file.type.startsWith("video/") ? "video" : "image";
      } catch (_) { showToast("Couldn't read that file. Try another one."); return; }
    }
    const post = {id:"post-" + Date.now(),name:profile.name || "DND Creator",topic:$("#post-topic").value,text,media,mediaType,likes:0,liked:false,time:"Just now"};
    posts.unshift(post);
    if (!save("dnd_posts", posts)) { posts.shift(); return; }
    $("#post-text").value = "";
    $("#post-file").value = "";
    $("#file-name").textContent = "No file selected";
    goToPage("home");
    showToast("Post added to this browser's local feed.");
  }
  function saveProfile(event) {
    event.preventDefault();
    profile = {name:$("#display-name").value.trim() || "DND Creator",bio:$("#profile-bio").value.trim()};
    save("dnd_profile", profile);
    renderProfile();
    showToast("Profile saved on this device.");
  }
  function clearLocalData() {
    if (!window.confirm("Clear DND Social posts and profile saved in this browser? This cannot be undone.")) return;
    localStorage.removeItem("dnd_posts");
    localStorage.removeItem("dnd_profile");
    posts = [];
    profile = {name:"DND Creator",bio:"Making my mark, one post at a time."};
    renderFeed(); renderExplore(); renderVideos(); renderDashboard(); renderProfile();
    showToast("Local demo data cleared.");
  }
  document.addEventListener("click", event => {
    const pageButton = event.target.closest("[data-page-link]");
    if (pageButton) { event.preventDefault(); goToPage(pageButton.dataset.pageLink); return; }
    const like = event.target.closest("[data-like]");
    if (like) { toggleLike(like.dataset.like); return; }
    const share = event.target.closest("[data-share]");
    if (share) { sharePost(share.dataset.share); return; }
    const del = event.target.closest("[data-delete]");
    if (del) {
      if (window.confirm("Delete this local post?")) {
        posts = posts.filter(post => post.id !== del.dataset.delete);
        save("dnd_posts", posts);
        renderFeed(); renderExplore(); renderVideos(); renderDashboard(); renderProfile();
        showToast("Post deleted from this browser.");
      }
      return;
    }
    const topic = event.target.closest("[data-topic]");
    if (topic) {
      goToPage("explore");
      $("#explore-search").value = topic.dataset.topic;
      renderExplore();
      return;
    }
    const product = event.target.closest("[data-product]");
    if (product) showToast("Demo listing only — checkout is not connected.");
  });
  $("#create-form").addEventListener("submit", createPost);
  $("#profile-form").addEventListener("submit", saveProfile);
  $("#global-search").addEventListener("input", () => {
    if (!$("#page-explore").classList.contains("active")) goToPage("home");
    renderFeed();
  });
  $("#explore-search").addEventListener("input", renderExplore);
  $("#feed-sort").addEventListener("change", renderFeed);
  $("#market-search").addEventListener("input", renderProducts);
  $("#post-file").addEventListener("change", event => {
    $("#file-name").textContent = event.target.files[0]?.name || "No file selected";
  });
  $("#sell-button").addEventListener("click", () => showToast("Seller listings will be enabled after accounts and the marketplace backend are built."));
  $("#clear-local").addEventListener("click", clearLocalData);
  renderFeed(); renderExplore(); renderVideos(); renderProducts(); renderDashboard(); renderProfile();
})();
